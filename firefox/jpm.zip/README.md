#FxPlus+ Beta
God, this is hell to make